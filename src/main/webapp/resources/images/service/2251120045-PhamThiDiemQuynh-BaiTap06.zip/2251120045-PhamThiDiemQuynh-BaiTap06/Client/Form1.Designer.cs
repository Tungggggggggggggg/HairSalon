﻿namespace Client_BDB
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonDisconnect = new Button();
            buttonConnect = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            textBoxIP = new TextBox();
            textBoxPort = new TextBox();
            richTextRxMessage = new TextBox();
            textBoxConnectStatus = new TextBox();
            richTextTxMessage = new TextBox();
            buttonSendMessage = new Button();
            button4 = new Button();
            buttonClose = new Button();
            SuspendLayout();
            // 
            // buttonDisconnect
            // 
            buttonDisconnect.Location = new Point(645, 34);
            buttonDisconnect.Name = "buttonDisconnect";
            buttonDisconnect.Size = new Size(94, 79);
            buttonDisconnect.TabIndex = 0;
            buttonDisconnect.Text = "Disconnect From Server";
            buttonDisconnect.UseVisualStyleBackColor = true;
            buttonDisconnect.Click += buttonDisconnect_Click;
            // 
            // buttonConnect
            // 
            buttonConnect.Location = new Point(471, 34);
            buttonConnect.Name = "buttonConnect";
            buttonConnect.Size = new Size(94, 79);
            buttonConnect.TabIndex = 1;
            buttonConnect.Text = "Connect To Server";
            buttonConnect.UseVisualStyleBackColor = true;
            buttonConnect.Click += buttonConnect_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 38);
            label1.Name = "label1";
            label1.Size = new Size(124, 20);
            label1.TabIndex = 2;
            label1.Text = "Server Ip Address";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 130);
            label2.Name = "label2";
            label2.Size = new Size(132, 20);
            label2.TabIndex = 3;
            label2.Text = "Message To Server";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 72);
            label3.Name = "label3";
            label3.Size = new Size(80, 20);
            label3.TabIndex = 4;
            label3.Text = "Server Port";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(471, 140);
            label4.Name = "label4";
            label4.Size = new Size(150, 20);
            label4.TabIndex = 5;
            label4.Text = "Message From Server";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 392);
            label6.Name = "label6";
            label6.Size = new Size(128, 20);
            label6.TabIndex = 7;
            label6.Text = "Connection Status";
            // 
            // textBoxIP
            // 
            textBoxIP.Location = new Point(144, 40);
            textBoxIP.Name = "textBoxIP";
            textBoxIP.Size = new Size(125, 27);
            textBoxIP.TabIndex = 8;
            // 
            // textBoxPort
            // 
            textBoxPort.Location = new Point(144, 73);
            textBoxPort.Name = "textBoxPort";
            textBoxPort.Size = new Size(125, 27);
            textBoxPort.TabIndex = 9;
            // 
            // richTextRxMessage
            // 
            richTextRxMessage.Location = new Point(471, 163);
            richTextRxMessage.Multiline = true;
            richTextRxMessage.Name = "richTextRxMessage";
            richTextRxMessage.Size = new Size(317, 149);
            richTextRxMessage.TabIndex = 10;
            // 
            // textBoxConnectStatus
            // 
            textBoxConnectStatus.BorderStyle = BorderStyle.None;
            textBoxConnectStatus.ForeColor = SystemColors.HotTrack;
            textBoxConnectStatus.Location = new Point(150, 392);
            textBoxConnectStatus.Name = "textBoxConnectStatus";
            textBoxConnectStatus.Size = new Size(125, 20);
            textBoxConnectStatus.TabIndex = 11;
            textBoxConnectStatus.Text = "Not Connected";
            // 
            // richTextTxMessage
            // 
            richTextTxMessage.Location = new Point(12, 153);
            richTextTxMessage.Multiline = true;
            richTextTxMessage.Name = "richTextTxMessage";
            richTextTxMessage.Size = new Size(257, 159);
            richTextTxMessage.TabIndex = 12;
            // 
            // buttonSendMessage
            // 
            buttonSendMessage.Location = new Point(12, 318);
            buttonSendMessage.Name = "buttonSendMessage";
            buttonSendMessage.Size = new Size(257, 29);
            buttonSendMessage.TabIndex = 13;
            buttonSendMessage.Text = "Send Message";
            buttonSendMessage.UseVisualStyleBackColor = true;
            buttonSendMessage.Click += buttonSendMessage_Click;
            // 
            // button4
            // 
            button4.Location = new Point(584, 330);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 14;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = true;
            // 
            // buttonClose
            // 
            buttonClose.Location = new Point(694, 330);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(94, 29);
            buttonClose.TabIndex = 15;
            buttonClose.Text = "Close";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonClose);
            Controls.Add(button4);
            Controls.Add(buttonSendMessage);
            Controls.Add(richTextTxMessage);
            Controls.Add(textBoxConnectStatus);
            Controls.Add(richTextRxMessage);
            Controls.Add(textBoxPort);
            Controls.Add(textBoxIP);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonConnect);
            Controls.Add(buttonDisconnect);
            Name = "Form1";
            Text = "Client";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonDisconnect;
        private Button buttonConnect;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private TextBox textBoxIP;
        private TextBox textBoxPort;
        private TextBox richTextRxMessage;
        private TextBox textBoxConnectStatus;
        private TextBox richTextTxMessage;
        private Button buttonSendMessage;
        private Button button4;
        private Button buttonClose;
    }
}