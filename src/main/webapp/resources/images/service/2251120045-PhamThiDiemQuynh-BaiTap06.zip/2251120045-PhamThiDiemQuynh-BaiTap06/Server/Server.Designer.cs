﻿namespace Server_BDB
{
    partial class Server
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonStartListen = new Button();
            buttonStopListen = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBoxIP = new TextBox();
            textBoxPort = new TextBox();
            richTextBoxReceivedMsg = new TextBox();
            richTextBoxSendMsg = new TextBox();
            textBoxMsg = new TextBox();
            buttonClose = new Button();
            button4 = new Button();
            buttonSendMsg = new Button();
            SuspendLayout();
            // 
            // buttonStartListen
            // 
            buttonStartListen.Location = new Point(468, 35);
            buttonStartListen.Name = "buttonStartListen";
            buttonStartListen.Size = new Size(94, 50);
            buttonStartListen.TabIndex = 0;
            buttonStartListen.Text = "Start Listening";
            buttonStartListen.UseVisualStyleBackColor = true;
            buttonStartListen.Click += buttonStartListen_Click;
            // 
            // buttonStopListen
            // 
            buttonStopListen.Location = new Point(656, 35);
            buttonStopListen.Name = "buttonStopListen";
            buttonStopListen.Size = new Size(94, 50);
            buttonStopListen.TabIndex = 1;
            buttonStopListen.Text = "Stop Listening";
            buttonStopListen.UseVisualStyleBackColor = true;
            buttonStopListen.Click += buttonStopListen_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 24);
            label1.Name = "label1";
            label1.Size = new Size(67, 20);
            label1.TabIndex = 2;
            label1.Text = "Server Ip";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 280);
            label2.Name = "label2";
            label2.Size = new Size(122, 20);
            label2.TabIndex = 3;
            label2.Text = "Connected Client";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 110);
            label3.Name = "label3";
            label3.Size = new Size(199, 20);
            label3.TabIndex = 4;
            label3.Text = "Broadcast Message To Client";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 65);
            label4.Name = "label4";
            label4.Size = new Size(35, 20);
            label4.TabIndex = 5;
            label4.Text = "Port";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(468, 124);
            label5.Name = "label5";
            label5.Size = new Size(223, 20);
            label5.TabIndex = 6;
            label5.Text = "Messages Received From Clients";
            // 
            // textBoxIP
            // 
            textBoxIP.Location = new Point(125, 24);
            textBoxIP.Name = "textBoxIP";
            textBoxIP.Size = new Size(125, 27);
            textBoxIP.TabIndex = 8;
            textBoxIP.Text = "127.0.0.1";
            // 
            // textBoxPort
            // 
            textBoxPort.Location = new Point(125, 65);
            textBoxPort.Name = "textBoxPort";
            textBoxPort.Size = new Size(125, 27);
            textBoxPort.TabIndex = 9;
            textBoxPort.Text = "8000";
            // 
            // richTextBoxReceivedMsg
            // 
            richTextBoxReceivedMsg.Location = new Point(468, 147);
            richTextBoxReceivedMsg.Multiline = true;
            richTextBoxReceivedMsg.Name = "richTextBoxReceivedMsg";
            richTextBoxReceivedMsg.Size = new Size(320, 235);
            richTextBoxReceivedMsg.TabIndex = 11;
            // 
            // richTextBoxSendMsg
            // 
            richTextBoxSendMsg.Location = new Point(34, 133);
            richTextBoxSendMsg.Multiline = true;
            richTextBoxSendMsg.Name = "richTextBoxSendMsg";
            richTextBoxSendMsg.Size = new Size(223, 91);
            richTextBoxSendMsg.TabIndex = 12;
            // 
            // textBoxMsg
            // 
            textBoxMsg.Location = new Point(34, 303);
            textBoxMsg.Multiline = true;
            textBoxMsg.Name = "textBoxMsg";
            textBoxMsg.Size = new Size(223, 106);
            textBoxMsg.TabIndex = 13;
            // 
            // buttonClose
            // 
            buttonClose.Location = new Point(631, 388);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(94, 29);
            buttonClose.TabIndex = 14;
            buttonClose.Text = "Close";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // button4
            // 
            button4.Location = new Point(468, 388);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 15;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = true;
            // 
            // buttonSendMsg
            // 
            buttonSendMsg.Location = new Point(34, 230);
            buttonSendMsg.Name = "buttonSendMsg";
            buttonSendMsg.Size = new Size(223, 32);
            buttonSendMsg.TabIndex = 16;
            buttonSendMsg.Text = "Send Message";
            buttonSendMsg.UseVisualStyleBackColor = true;
            buttonSendMsg.Click += buttonSendMsg_Click;
            // 
            // Server
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonSendMsg);
            Controls.Add(button4);
            Controls.Add(buttonClose);
            Controls.Add(textBoxMsg);
            Controls.Add(richTextBoxSendMsg);
            Controls.Add(richTextBoxReceivedMsg);
            Controls.Add(textBoxPort);
            Controls.Add(textBoxIP);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonStopListen);
            Controls.Add(buttonStartListen);
            Name = "Server";
            Text = "Server";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonStartListen;
        private Button buttonStopListen;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBoxIP;
        private TextBox textBoxPort;
        private TextBox richTextBoxReceivedMsg;
        private TextBox richTextBoxSendMsg;
        private TextBox textBoxMsg;
        private Button buttonClose;
        private Button button4;
        private Button buttonSendMsg;
    }
}