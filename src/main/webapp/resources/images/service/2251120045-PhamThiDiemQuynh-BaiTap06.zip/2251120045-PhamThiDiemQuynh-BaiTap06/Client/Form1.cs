using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Threading;
using Timer = System.Threading.Timer;
using System.Diagnostics;
using System.Text;

namespace Client_BDB
{
    public partial class Form1 : Form
    {
        byte[] m_dataBuffer = new byte[10];
        IAsyncResult m_result;
        public AsyncCallback m_pfnCallBack;
        public Socket m_clientSocket;
        System.Threading.Timer messageTimer;

        public Form1()
        {
            InitializeComponent();
            textBoxIP.Text = GetIP();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            CloseConnection();
            Close();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxIP.Text) || string.IsNullOrWhiteSpace(textBoxPort.Text))
            {
                MessageBox.Show("IP Address and Port Number are required to connect to the Server.");
                return;
            }

            try
            {
                UpdateControls(false);
                IPAddress ip = IPAddress.Parse(textBoxIP.Text);
                int iPortNo = Convert.ToInt32(textBoxPort.Text);
                IPEndPoint ipEnd = new IPEndPoint(ip, iPortNo);
                m_clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                m_clientSocket.Connect(ipEnd);

                if (m_clientSocket.Connected)
                {
                    UpdateControls(true);
                    WaitForData();
                }
            }
            catch (SocketException se)
            {
                MessageBox.Show($"Connection failed, is the server running?\n{se.Message}");
                UpdateControls(false);
            }
        }

        private void UpdateControls(bool connected)
        {
            buttonConnect.Enabled = !connected;
            buttonDisconnect.Enabled = connected;
            buttonSendMessage.Enabled = connected;
            textBoxConnectStatus.Text = connected ? "Connected" : "Not Connected";
        }

        public void WaitForData()
        {
            if (m_pfnCallBack == null)
            {
                m_pfnCallBack = new AsyncCallback(OnDataReceived);
            }
            SocketPacket theSocPkt = new SocketPacket();
            theSocPkt.thisSocket = m_clientSocket;
            m_result = m_clientSocket.BeginReceive(theSocPkt.dataBuffer, 0, theSocPkt.dataBuffer.Length, SocketFlags.None, m_pfnCallBack, theSocPkt);
        }

        public void OnDataReceived(IAsyncResult asyn)
        {
            try
            {
                SocketPacket theSockId = (SocketPacket)asyn.AsyncState;
                int iRx = theSockId.thisSocket.EndReceive(asyn);
                char[] chars = new char[iRx];
                Decoder d = Encoding.UTF8.GetDecoder();
                int charLen = d.GetChars(theSockId.dataBuffer, 0, iRx, chars, 0);
                string szData = new string(chars);
                richTextRxMessage.Invoke(new MethodInvoker(delegate
                {
                    richTextRxMessage.AppendText(szData);
                }));
                WaitForData();
            }
            catch (ObjectDisposedException)
            {
                Debugger.Log(0, "1", "\nOnDataReceived: Socket has been closed\n");
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message);
            }
        }

        private void buttonSendMessage_Click(object sender, EventArgs e)
        {
            if (int.TryParse(richTextTxMessage.Text, out int delaySeconds))
            {
                messageTimer?.Dispose();  // Dispose previous timer if it exists
                messageTimer = new Timer(MessageTimer_Tick, null, delaySeconds * 1000, Timeout.Infinite);
            }
            else
            {
                MessageBox.Show("Please enter a valid number of seconds.");
            }
        }
        public class SocketPacket
        {
            public System.Net.Sockets.Socket thisSocket;
            public byte[] dataBuffer = new byte[1024];  // Adjust buffer size as needed

            public SocketPacket()
            {
                thisSocket = null;
            }

            public SocketPacket(Socket socket)
            {
                thisSocket = socket;
            }
        }

        private void MessageTimer_Tick(object state)
        {
            if (m_clientSocket != null && m_clientSocket.Connected)
            {
                byte[] byData = Encoding.ASCII.GetBytes(richTextTxMessage.Text);
                m_clientSocket.Send(byData);
            }
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            CloseConnection();
        }

        private void CloseConnection()
        {
            if (m_clientSocket != null)
            {
                m_clientSocket.Close();
                m_clientSocket = null;
                UpdateControls(false);
            }
        }

        string GetIP()
        {
            string hostName = Dns.GetHostName();
            IPHostEntry iphostentry = Dns.GetHostEntry(hostName);
            foreach (IPAddress ipaddress in iphostentry.AddressList)
            {
                if (ipaddress.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ipaddress.ToString();
                }
            }
            return "127.0.0.1"; // Return localhost if no IPv4 address is found
        }
    }
}
